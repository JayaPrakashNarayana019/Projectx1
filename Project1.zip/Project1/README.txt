#This is My First Project 
#JayaPrakashNarayana
#Date:10th Nov,2019.

#Included all the 6 screenshots requested.

#Website Address when CloudFront Was Created: -- http://d32wwo73ss5hc8.cloudfront.net/index.html




						